<?php //login.php
$db_hostname = 'localhost';
$db_database = 'CS143';
$db_username = 'cs143';
$db_password = '';
?>